<x-app-layout> @section('content')
    Dashboard
@endsection
</x-app-layout>

@extends('layouts.app-ui') @section('content')
    Dashboard
@endsection